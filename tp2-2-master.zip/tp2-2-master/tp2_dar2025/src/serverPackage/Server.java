package serverPackage;

import java.io.*;
import java.net.*;

import ClientPackage.CalculOp;

public class Server {

	public static void main(String[] args) throws ClassNotFoundException{
		// TODO Auto-generated method stub
//
		try {
			InetAddress ip=InetAddress.getLocalHost();
			ServerSocket socketServeur = new ServerSocket();
			socketServeur.bind(new InetSocketAddress(ip,1234));
			System.out.println("le serveur est en ecoute sur "+ip.getHostAddress());
			
			Socket socket = socketServeur.accept();
			System.out.println("un client est connecte");
			
			InputStream is = socket.getInputStream();
			BufferedReader reader=new BufferedReader(new InputStreamReader(is));
			OutputStream os=socket.getOutputStream();
			PrintWriter writer=new PrintWriter(os,true);
			ObjectInputStream ois=new ObjectInputStream(is);
			CalculOp cl=(CalculOp)ois.readObject();
			
			int nb1=cl.getX1();
			String op=cl.getOp();
			int nb2=cl.getX2();
			
			int res=0;
			switch(op) {
			case "+":
				res=nb1+nb2;
				break;
			case "-":
				res=nb1-nb2;
				break;
			case "*":
				res=nb1*nb2;
				break;
			case "/":
				res=nb1/nb2;
				break;
			default:writer.println("operation invalide");socket.close();return;
			}
			writer.println("resultat :"+res);
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
