package ClientPackage;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.net.*;
public class Client {

	public static void main(String[] args) throws  IOException {
		Scanner sc=new Scanner(System.in);
		Socket socket = new Socket("192.168.56.1", 1234);
		
		OutputStream os = socket.getOutputStream();
		PrintWriter writer=new PrintWriter(os,true);
		InputStream is=socket.getInputStream();
		BufferedReader reader=new BufferedReader(new InputStreamReader(is));
		ObjectOutputStream oos=new ObjectOutputStream(os);
		System.out.println("Donnez le premier opérateur");
		int x1=sc.nextInt();
		String op;
		System.out.println("Donnez l'opérateur (+, -, *, /)");
		do {
            
            op = sc.nextLine();
        } while (!op.equals("+") && !op.equals("-") && !op.equals("*") && !op.equals("/"));
		System.out.println("Donnez le deuxieme opérateur");
		int x2=sc.nextInt();
		
		CalculOp clp=new CalculOp(x1,op,x2);
		oos.writeObject(clp);
		
		String res=reader.readLine();
		System.out.println(res);
		
		socket.close();
	}

}

