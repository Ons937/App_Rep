package ClientPackage;
import java.io.*;
public class CalculOp implements Serializable{
	private int x1;
	private String op;
	private int x2;
	public CalculOp(int x1,String op,int x2) {
		this.x1=x1;
		this.op=op;
		this.x2=x2;
	}
	public int getX1() {
		return x1;
	}
	public void setX1(int x1) {
		this.x1 = x1;
	}
	public String getOp() {
		return op;
	}
	public void setOp(String op) {
		this.op = op;
	}
	public int getX2() {
		return x2;
	}
	public void setX2(int x2) {
		this.x2 = x2;
	}
	@Override
	public String toString() {
		return "CalculOp [x1=" + x1 + ", op=" + op + ", x2=" + x2 + "]";
	}

}
